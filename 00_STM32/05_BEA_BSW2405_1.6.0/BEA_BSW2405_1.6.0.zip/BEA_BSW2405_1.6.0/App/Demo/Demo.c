/*
 * Demo.c
 *
 *  Created on: May 18, 2024
 *      Author: HP
 */
/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "LED_PC13.h"
#include "MPUXX50.h"
#include "ina219.h"
#include "VL53L1X_API.h"
#include "VL53l1X_calibration.h"
#include "Demo.h"
extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c2;
extern uint8_t _buffer[21];
extern Attitude attitude;
// Structures
extern RawData rawData;

extern SensorData sensorData;

extern GyroCal gyroCal;

int16_t AccData[3], GyroData[3], MagData[3];
INA219_t myINA219;
uint16_t	dev=0x52;
int status=0;
int GY91_InitState=0;
dataESP32 mydataESP32;
ESP32_TransType myESP32_TransType=ESP32_INIT_TRANS;

void Demo_TestLED_Proc_100ms()
{
	static uint16_t cnt=0;
	static uint8_t led_mode=0;
	//char snum[6]={'H','e','l','l','o','!'};
	//itoa(41244, snum, 10);
	if(cnt%10==0)
	{
		//LED_Set_BlinkMode(led_mode%8);
		led_mode++;

		if(myESP32_TransType == ESP32_END_TRANS)
		{
			myESP32_TransType = ESP32_INIT_TRANS;
		}

	}
	cnt++;

}

void Demo_GetGYdata_Proc_10ms()
{
	static uint16_t cnt=0;
	int16_t ax, ay, az;

//	if(cnt%10==0 )
//	{
		MPU_calcAttitude(&hi2c1);
		itoa((int8_t)(attitude.r),&mydataESP32.GY91[0],10);
		itoa((int8_t)(attitude.p),&mydataESP32.GY91[8],10);
		itoa((int8_t)(attitude.y),&mydataESP32.GY91[16],10);
		//itoa(MPU9250_ReadWhoAmI(&hi2c1),&mydataESP32.GY91[24],16);
//		char buffer[50];
//		if (MPU9250_ReadAccelerometer(&hi2c1, &ax, &ay, &az) == HAL_OK)
//		{
//			itoa(ax,&mydataESP32.GY91[0],10);
//			itoa(ay,&mydataESP32.GY91[8],10);
//			itoa(az,&mydataESP32.GY91[16],10);
//			itoa(MPU9250_ReadWhoAmI(&hi2c1),&mydataESP32.GY91[24],16);
//		} else
//		{
//			;
//		}
//	}
//	cnt++;

}

void Demo_Init_Proc()
{
	uint8_t byteData, sensorState=0;
	uint16_t wordData;

	LED_Set_BlinkMode(LED_BLINKMODE_1Hz);

	if(!INA219_Init(&myINA219, &hi2c1, 0x40, 0.4))
	{
		LED_Set_BlinkMode(LED_BLINKMODE_5Hz);
	}
	for (int i=0;i<32;i++)
	{
		mydataESP32.GY91[i]='?';
		mydataESP32.INA219[i]='?';
		mydataESP32.VL53L1X[i]='?';
	}
	mydataESP32.Test[0] = 'H';
	mydataESP32.Test[1] = 'e';
	mydataESP32.Test[2] = 'l';
	mydataESP32.Test[3] = 'l';
	mydataESP32.Test[4] = 'o';
	mydataESP32.Test[5] = '!';

	//
//    if (MPU9250_Init(&hi2c1) != HAL_OK) {
//    	LED_Set_BlinkMode(LED_BLINKMODE_PATERN_1);
//    }

    // Check if IMU configured properly and block if it didn't
      if (MPU_begin(&hi2c1, AD0_LOW, AFSR_4G, GFSR_500DPS, 0.98, 0.01) == 1)
      {
        //HAL_GPIO_WritePin(LED_PORT, LED_PIN, 1);
    	  MPU_calibrateGyro(&hi2c1, 1500);
      }
      else
      {
    	  LED_Set_BlinkMode(LED_BLINKMODE_PATERN_1);
      }

//
//	//
//	/* Those basic I2C read functions can be used to check your own I2C functions */
//	status = VL53L1_RdByte(dev, 0x010F, &byteData);
//	//printf("VL53L1X Model_ID: %X\n", byteData);
//	itoa(byteData,&mydataESP32.VL53L1X[0],16);
//
//	status = VL53L1_RdByte(dev, 0x0110, &byteData);
//	//printf("VL53L1X Module_Type: %X\n", byteData);
//	itoa(byteData,&mydataESP32.VL53L1X[4],16);
//
//	status = VL53L1_RdWord(dev, 0x010F, &wordData);
//	//printf("VL53L1X: %X\n", wordData);
//	itoa(wordData,&mydataESP32.VL53L1X[8],16);
//
//	while(sensorState==0){
//		status = VL53L1X_BootState(dev, &sensorState);
//	HAL_Delay(2);
//	}
//	//printf("Chip booted\n");
//	 /* This function must to be called to initialize the sensor with the default setting  */
//	status = VL53L1X_SensorInit(dev);
//	/* Optional functions to be used to change the main ranging parameters according the application requirements to get the best ranging performances */
//	status = VL53L1X_SetDistanceMode(dev, 2); /* 1=short, 2=long */
//	status = VL53L1X_SetTimingBudgetInMs(dev, 100); /* in ms possible values [20, 50, 100, 200, 500] */
//	status = VL53L1X_SetInterMeasurementInMs(dev, 100); /* in ms, IM must be > = TB */
//	//  status = VL53L1X_SetOffset(dev,20); /* offset compensation in mm */
//	//  status = VL53L1X_SetROI(dev, 16, 16); /* minimum ROI 4,4 */
//	//	status = VL53L1X_CalibrateOffset(dev, 140, &offset); /* may take few second to perform the offset cal*/
//	//	status = VL53L1X_CalibrateXtalk(dev, 1000, &xtalk); /* may take few second to perform the xtalk cal */
//	//printf("VL53L1X Ultra Lite Driver Example running ...\n");
}

void Demo_INA219_Proc_100ms()
{
	static uint16_t cnt=0;
	uint16_t busVol=0;
	uint16_t busCur_mA=0;
	char snum[5];
	double busCur;

	if(cnt%10==0)
	{
		busVol = INA219_ReadBusVoltage(&myINA219);
		busCur = INA219_ReadCurrent(&myINA219);
		busCur_mA = (uint16_t)(busCur*1000);
		itoa(busVol,&mydataESP32.INA219[0],10);
		itoa(busCur_mA,&mydataESP32.INA219[10],10);

	}
	cnt++;

}


void Demo_VL53L1X_Proc_100ms()
{
	static uint16_t cnt=0;
	uint8_t byteData, sensorState=0;
	uint16_t wordData;
	char snum[5];
	uint8_t ToFSensor = 1; // 0=Left, 1=Center(default), 2=Right
	uint16_t Distance;
	uint16_t SignalRate;
	uint16_t AmbientRate;
	uint16_t SpadNum;
	uint8_t RangeStatus;
	uint8_t dataReady;
	if(cnt%10==0)
	{

		  status = VL53L1X_StartRanging(dev);   /* This function has to be called to enable the ranging */
		  while (dataReady == 0){
		  		  status = VL53L1X_CheckForDataReady(dev, &dataReady);
		  		  HAL_Delay(2);
		  	  }
		  	  dataReady = 0;
		  	  status = VL53L1X_GetRangeStatus(dev, &RangeStatus);
		  	  status = VL53L1X_GetDistance(dev, &Distance);
		  	  status = VL53L1X_GetSignalRate(dev, &SignalRate);
		  	  status = VL53L1X_GetAmbientRate(dev, &AmbientRate);
		  	  status = VL53L1X_GetSpadNb(dev, &SpadNum);
		  	  status = VL53L1X_ClearInterrupt(dev); /* clear interrupt has to be called to enable next interrupt*/
		  	  itoa(Distance,&mydataESP32.VL53L1X[16],10);
		  	  //itoa(RangeStatus,&mydataESP32.VL53L1X[22],10);
		  	  //itoa(SignalRate,&mydataESP32.VL53L1X[26],10);
	}
	cnt++;

}

void Demo_ESP32_Senddata_Proc_10ms(char *data, int len)
{
	HAL_StatusTypeDef esp32_stTrans = HAL_OK;
	switch(myESP32_TransType)
	{
	case ESP32_INIT_TRANS:
		esp32_stTrans = HAL_I2C_Master_Transmit(&hi2c2, 0x12 << 1, mydataESP32.Test, 6, HAL_MAX_DELAY);
		if(esp32_stTrans==HAL_OK)
		{
			myESP32_TransType = ESP32_INA219_TRANS;
		}
		break;
	case ESP32_INA219_TRANS:
		esp32_stTrans = HAL_I2C_Master_Transmit(&hi2c2, 0x12 << 1, mydataESP32.INA219, ESP32_DATA_LEN, HAL_MAX_DELAY);
		if(esp32_stTrans==HAL_OK)
		{
			myESP32_TransType = ESP32_VL53L1X_TRANS;
		}
		break;
	case ESP32_VL53L1X_TRANS:
		esp32_stTrans = HAL_I2C_Master_Transmit(&hi2c2, 0x12 << 1, mydataESP32.VL53L1X, ESP32_DATA_LEN, HAL_MAX_DELAY);
		if(esp32_stTrans==HAL_OK)
		{
			myESP32_TransType = ESP32_GY91_TRANS;
		}
		break;
	case ESP32_GY91_TRANS:
		esp32_stTrans = HAL_I2C_Master_Transmit(&hi2c2, 0x12 << 1, mydataESP32.GY91, ESP32_DATA_LEN, HAL_MAX_DELAY);
		if(esp32_stTrans==HAL_OK)
		{
			myESP32_TransType = ESP32_END_TRANS;
		}
		break;
	default:
		break;
	}
}
