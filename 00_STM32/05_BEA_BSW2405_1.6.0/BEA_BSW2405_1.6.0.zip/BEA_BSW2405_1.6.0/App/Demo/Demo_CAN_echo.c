/*
 * Demo_CAN_echo.c
 *
 *  Created on: Jun 6, 2024
 *      Author: nda9hc
 */


#include "Demo_CAN_echo.h"

#include "BSW/CANStack/mcal_can.h"
#include "BSW/Utils/us_memcpy.h"

void CAN_Init_proc(void) {
  can_start();
}

void CAN_echo_Proc_1ms(void) {
  if (can_rx_available() == CAN_SUCCESS) {
	can_tx_msg_t tx_msg;
	const can_rx_msg_t* rx_msg = can_receive();
    tx_msg.header.StdId = rx_msg->header.StdId + 1;
    tx_msg.header.ExtId = rx_msg->header.ExtId + 1;
	tx_msg.header.IDE = rx_msg->header.IDE;
	tx_msg.header.DLC = rx_msg->header.DLC;
	tx_msg.header.RTR = rx_msg->header.RTR;
	us_memcpy(tx_msg.data, rx_msg->data, rx_msg->header.DLC);

	can_send(&tx_msg);

	can_process_next();
  }
}
