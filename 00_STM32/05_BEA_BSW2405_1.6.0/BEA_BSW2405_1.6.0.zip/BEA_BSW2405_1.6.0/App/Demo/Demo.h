/*
 * Demo.h
 *
 *  Created on: May 18, 2024
 *      Author: HP
 */

#ifndef DEMO_DEMO_H_
#define DEMO_DEMO_H_

#define ESP32_DATA_LEN 32
typedef struct  {
	char Test[6];
	char INA219[ESP32_DATA_LEN];
	char GY91[ESP32_DATA_LEN];
	char VL53L1X[ESP32_DATA_LEN];
} dataESP32;

typedef enum {
    ESP32_INIT_TRANS = 0,
	ESP32_INA219_TRANS,
	ESP32_VL53L1X_TRANS,
	ESP32_GY91_TRANS,
	ESP32_END_TRANS
} ESP32_TransType;

extern void Demo_TestLED_Proc_100ms();
extern void Demo_GetGYdata_Proc_100ms();
extern void Demo_INA219_Proc_100ms();
extern void Demo_Init_Proc();
extern void Demo_VL53L1X_Proc_100ms();
#endif /* DEMO_DEMO_H_ */
