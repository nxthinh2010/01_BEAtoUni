/*
 * Demo_CAN_echo.h
 *
 *  Created on: Jun 6, 2024
 *      Author: nda9hc
 */

#ifndef DEMO_DEMO_CAN_ECHO_H_
#define DEMO_DEMO_CAN_ECHO_H_

void CAN_Init_proc(void);
void CAN_echo_Proc_1ms(void);

#endif /* DEMO_DEMO_CAN_ECHO_H_ */
