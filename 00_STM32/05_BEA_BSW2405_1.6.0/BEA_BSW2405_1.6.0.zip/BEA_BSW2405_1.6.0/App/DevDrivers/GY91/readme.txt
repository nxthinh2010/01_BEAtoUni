https://github.com/MarkSherstan/MPU-6050-9250-I2C-CompFilter/tree/master/STM32/C/I2C

### Design Document for MPUXX50.c

#### Overview
This module interfaces with the MPU9250/MPU6050 IMU sensors using I2C, handling initialization, configuration, and data processing.

#### Functions
1. **MPU_begin()**: Initializes the IMU, sets address, checks connection, resets, and configures full-scale ranges.
2. **MPU_writeAccFullScaleRange()**: Sets the accelerometer's full-scale range based on input.
3. **MPU_writeGyroFullScaleRange()**: Sets the gyroscope's full-scale range based on input.
4. **MPU_readRawData()**: Reads raw accelerometer and gyroscope data from the IMU.
5. **MPU_calibrateGyro()**: Calibrates the gyroscope by averaging multiple readings.
6. **MPU_readProcessedData()**: Converts raw data to real-world units and compensates for offsets.
7. **MPU_calcAttitude()**: Calculates the sensor's attitude using a complementary filter.

#### Key Variables
- `_addr`: I2C address of the IMU.
- `_tau`: Complementary filter coefficient.
- `_dt`: Sampling rate.
- `aScaleFactor`, `gScaleFactor`: Scale factors for accelerometer and gyroscope.

#### Data Structures
- `rawData`, `sensorData`: Store raw and processed sensor data.
- `gyroCal`: Stores gyroscope calibration offsets.
- `attitude`: Stores calculated attitude (roll, pitch, yaw).