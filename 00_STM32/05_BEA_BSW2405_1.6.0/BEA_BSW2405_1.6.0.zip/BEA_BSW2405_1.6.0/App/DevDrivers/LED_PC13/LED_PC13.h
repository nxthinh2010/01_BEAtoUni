/*
 * LED_PC13.h
 *
 *  Created on: May 17, 2024
 *      Author: HP
 */

#ifndef LED_PC13_LED_PC13_H_
#define LED_PC13_LED_PC13_H_

#define LED_BLINKMODE_1Hz 			0 /* |^|_|_|_|_|_|_|_|_|_|^|_|_|_|_|_|_|_|_|_| */
#define LED_BLINKMODE_2Hz 			1 /* |^|_|_|_|_|^|_|_|_|_|^|_|_|_|_|^|_|_|_|_| */
#define LED_BLINKMODE_5Hz 			2 /* |^|_|^|_|^|_|^|_|^|_|^|_|^|_|^|_|^|_|^|_| */
#define LED_BLINKMODE_PATERN_1 		3 /* |^|_|^|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_| */
#define LED_BLINKMODE_PATERN_2 		4 /* |^|_|^|_|_|_|_|_|_|_|^|_|_|_|_|_|_|_|_|_| */
#define LED_BLINKMODE_PATERN_3 		5 /* |^|_|^|_|_|_|_|_|_|_|^|^|^|^|^|^|^|^|^|_| */
#define LED_BLINKMODE_ON 			6
#define LED_BLINKMODE_OFF 			7

extern void LED_BlinkMode_Proc_100ms();
extern void LED_Set_BlinkMode(uint8_t mode);
extern uint8_t LED_Get_BlinkMode();

#endif /* LED_PC13_LED_PC13_H_ */
