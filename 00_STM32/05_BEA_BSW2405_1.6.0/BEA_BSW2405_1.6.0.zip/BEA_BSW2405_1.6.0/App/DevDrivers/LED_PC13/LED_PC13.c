/*
 * LED_PC13.c
 *
 *  Created on: May 17, 2024
 *      Author: HP
 */
/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "LED_PC13.h"

uint8_t LED_BlinkMode = LED_BLINKMODE_PATERN_3;
static uint8_t LED_TimeCounter = 0;

void LED_BlinkMode_Proc_100ms()
{
	if(LED_TimeCounter==20)
	{
		LED_TimeCounter=0;
	}

	switch(LED_BlinkMode){

	case LED_BLINKMODE_1Hz:
		if((LED_TimeCounter%10)==0)
		{
			HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
		}
		break;

	case LED_BLINKMODE_2Hz:
		if((LED_TimeCounter%5)==0)
		{
			HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
		}
		break;

	case LED_BLINKMODE_5Hz:
		if((LED_TimeCounter%2)==0)
		{
			HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
		}
		break;

	case LED_BLINKMODE_ON:
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		break;

	case LED_BLINKMODE_OFF:
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		break;

	case LED_BLINKMODE_PATERN_1:
		if(LED_TimeCounter<1)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else if(LED_TimeCounter<2)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		else if(LED_TimeCounter<3)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		break;
	case LED_BLINKMODE_PATERN_2:
		if(LED_TimeCounter<1)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else if(LED_TimeCounter<2)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		else if(LED_TimeCounter<3)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else if(LED_TimeCounter<10)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		else if(LED_TimeCounter<11)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		break;
	case LED_BLINKMODE_PATERN_3:
		if(LED_TimeCounter<1)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else if(LED_TimeCounter<2)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		else if(LED_TimeCounter<3)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else if(LED_TimeCounter<10)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		else if(LED_TimeCounter<18)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		}
		break;
	default:
	}

	LED_TimeCounter++;
}

void LED_Set_BlinkMode(uint8_t mode)
{
	LED_BlinkMode = mode;
	LED_TimeCounter = 0;
}

uint8_t LED_Get_BlinkMode()
{
	return LED_BlinkMode;
}
