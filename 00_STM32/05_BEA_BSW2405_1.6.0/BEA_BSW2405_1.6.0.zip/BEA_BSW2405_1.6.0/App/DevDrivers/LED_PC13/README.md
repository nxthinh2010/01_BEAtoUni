# LED Blink Mode Controller Summary

The LED blink mode controller manages an LED connected to pin PC13 on an STM32 microcontroller, allowing it to blink in various patterns. Key components include:

- **Includes**: `"stm32f1xx_hal.h"`, `"LED_PC13.h"`.
- **Global Variables**: `LED_BlinkMode` (current mode), `LED_TimeCounter` (time tracking).

## Functions

### `LED_BlinkMode_Proc_100ms()`
- Called every 100ms.
- Updates LED state based on `LED_BlinkMode`.
- Modes:
  - **1Hz**: Toggle every 1s.
  - **2Hz**: Toggle every 0.5s.
  - **5Hz**: Toggle every 0.2s.
  - **ON**: LED on.
  - **OFF**: LED off.
  - **PATERN_1, 2, 3**: Custom blinking patterns.

### `LED_Set_BlinkMode(uint8_t mode)`
- Sets the blink mode.
- Resets `LED_TimeCounter`.

### `LED_Get_BlinkMode()`
- Returns current blink mode.

## Usage
1. Include `LED_PC13.h`.
2. Set mode with `LED_Set_BlinkMode(mode)`.
3. Call `LED_BlinkMode_Proc_100ms()` every 100ms (timer interrupt/main loop).

This controller supports various predefined blink modes and custom patterns for flexible LED control.