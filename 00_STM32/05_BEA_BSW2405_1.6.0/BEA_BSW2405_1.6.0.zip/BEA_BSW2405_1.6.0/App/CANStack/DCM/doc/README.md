# DCM server
## Brief

+ Provide UDS server function for diag control
+ Develop base on open source https://github.com/driftregion/iso14229
+ Wrapper for send and receive CAN msg from mcal_can

## How to build for project

### define preprocessor in project (SYSTEM CONSTANT)

+ UDS_SYS=UDS_SYS_CUSTOM
+ UDS_TP_ISOTP_C
+ UDS_CUSTOM_MILLIS

### DCM Config - dcm_conf.h

+ DCM_SVR_RX_ADDR - UDS server receive address (phys)
+ DCM_SVR_TX_ADDR - UDS server response address (phys)
+ DCM_SVR_FUNC_ADDR - UDS server functional address (func)

### Demo function

+ Address:
	#define DCM_SVR_RX_ADDR 0x7E8
	#define DCM_SVR_TX_ADDR 0x7E0
	#define DCM_SVR_FUNC_ADDR 0x7DF
+ SW reset -> positiveResponse (0x51)
	
### Testing

#### SW reset
send: 0x7E8 0x02 0x11 0x01
resp: 0x7E0 0x02 0x51 0x01