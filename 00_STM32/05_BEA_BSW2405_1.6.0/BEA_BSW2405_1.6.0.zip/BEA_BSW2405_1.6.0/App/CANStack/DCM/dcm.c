#include "dcm.h"
#include "dcm_conf.h"

#include "BSW/UDS/iso14229.h"
#include "BSW/CANStack/mcal_can.h"
#include "BSW/Utils/us_memcpy.h"

static UDSServer_t dcm_srv;
static UDSISOTpC_t dcm_tp;

uint32_t UDSMillis(void) {
  return HAL_GetTick();
}

static int send_can(const uint32_t arb_id, const uint8_t *data, const uint8_t size, void *ud) {
  can_tx_msg_t tx_msg;
  if (arb_id <= 0x7FF) { //CAN Standard
    tx_msg.header.StdId = arb_id;
    tx_msg.header.IDE = CAN_ID_STD;
  } else {
    tx_msg.header.ExtId = arb_id;
    tx_msg.header.IDE = CAN_ID_EXT;
  }
  tx_msg.header.DLC = size;
  us_memcpy(tx_msg.data, data, size);
  can_send(&tx_msg);
  return size;
}

const UDSISOTpCConfig_t tp_cfg = {
    .source_addr=DCM_SVR_RX_ADDR,
    .target_addr=DCM_SVR_TX_ADDR,
    .source_addr_func=DCM_SVR_FUNC_ADDR,
    .target_addr_func=UDS_TP_NOOP_ADDR,
    .isotp_user_send_can=send_can,
    .isotp_user_get_ms=UDSMillis,
    .isotp_user_debug=NULL,
    .user_data=NULL,
};

static void isotp_can_recv(UDSISOTpC_t *tp) {
  assert(tp);

  if (can_rx_available() == CAN_SUCCESS) {
    const can_rx_msg_t* rx_msg = can_receive();
    if ((rx_msg->header.StdId == tp->phys_sa) || (rx_msg->header.ExtId == tp->phys_sa)) {
      isotp_on_can_message(&tp->phys_link, (uint8_t *)rx_msg->data, rx_msg->header.DLC);
    } else if ((rx_msg->header.StdId == tp->phys_sa) || (rx_msg->header.ExtId == tp->func_sa)) {
      if (ISOTP_RECEIVE_STATUS_IDLE != tp->phys_link.receive_status) {
        return;
      }
      isotp_on_can_message(&tp->func_link, (uint8_t *)rx_msg->data, rx_msg->header.DLC);
    }
    can_process_next();
  }
}

uint8_t dcm_fn(UDSServer_t *srv, int ev, const void *arg) {
   switch(ev) {
    case UDS_SRV_EVT_EcuReset:
      return kPositiveResponse;
    default:
      return kServiceNotSupported;
  }
}

void dcm_proc_init(void) {
  if(UDSServerInit(&dcm_srv) != UDS_OK) {
    // failed
    while(1);
  }

  if (UDSISOTpCInit(&dcm_tp, &tp_cfg) != UDS_OK) {
    // failed
    while(1);
  }
  dcm_srv.tp = &dcm_tp.hdl;
  dcm_srv.fn = dcm_fn;

  can_start();
}

void dcm_proc_1ms(void) {
  UDSServerPoll(&dcm_srv);
  isotp_can_recv(&dcm_tp);
}

