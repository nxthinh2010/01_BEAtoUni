/*
 * dcm_conf.h
 *
 *  Created on: Jun 10, 2024
 *      Author: nda9hc
 */

#ifndef CANSTACK_DCM_DCM_CONF_H_
#define CANSTACK_DCM_DCM_CONF_H_

#define DCM_SVR_RX_ADDR 0x7E8
#define DCM_SVR_TX_ADDR 0x7E0
#define DCM_SVR_FUNC_ADDR 0x7DF

#endif /* CANSTACK_DCM_DCM_CONF_H_ */
