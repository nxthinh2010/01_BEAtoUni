#ifndef DEMO_DCM_H
# define DEMO_DCM_H

void dcm_proc_init(void);
void dcm_proc_1ms(void);

#endif