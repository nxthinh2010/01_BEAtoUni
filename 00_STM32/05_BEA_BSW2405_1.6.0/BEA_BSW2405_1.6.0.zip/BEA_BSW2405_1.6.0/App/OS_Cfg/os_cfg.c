/*
 * os_cfg.c
 *
 *  Created on: May 17, 2024
 *      Author: HP
 */
/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "CANStack/DCM/dcm.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

void osTask_Init()
{
	/* Schedule application task */

	/* BSW start */
	dcm_proc_init();
	/* BSW end */

	/* App start */

	/* App end */


}

void osTask_1ms()
{
	/* Schedule application task */

	/* BSW start */
	dcm_proc_1ms();
	/* BSW end */

	/* App start */
	/* App end */
}
void osTask_5ms()
{
	/* Schedule application task */

	/* BSW start */
	/* BSW end */

	/* App start */
	/* App end */
}
void osTask_10ms()
{
	/* Schedule application task */

	/* BSW start */
	/* BSW end */

	/* App start */

	/* App end */
}
void osTask_100ms()
{
	/* Schedule application task */

	/* BSW start */

	/* BSW end */

	/* App start */

	/* App end */
}


/* USER CODE BEGIN PFP */

