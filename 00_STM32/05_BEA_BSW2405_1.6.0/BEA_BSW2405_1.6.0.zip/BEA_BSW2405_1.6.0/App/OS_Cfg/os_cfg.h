/*
 * os_cfg.h
 *
 *  Created on: May 17, 2024
 *      Author: HP
 */

#ifndef INC_OS_CFG_H_
#define INC_OS_CFG_H_

extern void osTask_Init();
extern void osTask_1ms();
extern void osTask_5ms();
extern void osTask_10ms();
extern void osTask_100ms();


#endif /* INC_OS_CFG_H_ */
