#ifndef MCAL_CAN_CONF_H
# define MCAL_CAN_CONF_H

#define CAN_RX_BUFFER_SIZE 128

#endif
