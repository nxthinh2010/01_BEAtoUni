#include "mcal_can.h"
#include "mcal_can_conf.h"
#include "BSW/Utils/circular_buffer.h"

static circular_buff_t can_rx_fifo;
static can_rx_msg_t can_rx_msg_buff[CAN_RX_BUFFER_SIZE];

extern CAN_HandleTypeDef hcan;

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
  if (hcan->Instance == CAN1)
  {
    can_rx_msg_t rx_it;
    HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_it.header, rx_it.data);
    buffer_push(&can_rx_fifo, &rx_it, sizeof(can_rx_msg_t));
  }
}

void can_start(void)
{
  init_buffer(&can_rx_fifo, can_rx_msg_buff, CAN_RX_BUFFER_SIZE);
  // TODO: filter now accept for everything
  CAN_FilterTypeDef sFilterConfig = {0};
  sFilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  sFilterConfig.FilterIdHigh = 0;
  sFilterConfig.FilterIdLow = 0;
  sFilterConfig.FilterMaskIdHigh = 0;
  sFilterConfig.FilterMaskIdLow = 0;
  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
  sFilterConfig.FilterActivation = ENABLE;
  HAL_CAN_ConfigFilter(&hcan,&sFilterConfig);
  // start can and interrupt here
  HAL_CAN_Start(&hcan);
  HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
}

void can_stop(void)
{
  HAL_CAN_DeactivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
  HAL_CAN_Stop(&hcan);
}

void can_send(const can_tx_msg_t *msg)
{
  uint32_t TxMailbox;
  HAL_CAN_AddTxMessage(&hcan, &msg->header, msg->data, &TxMailbox);
}

const can_rx_msg_t *can_receive(void)
{
  return buffer_front(&can_rx_fifo, sizeof(can_rx_msg_t));
}

int32_t can_rx_available(void) {
  return buffer_available(&can_rx_fifo);
}

void can_process_next(void) {
  buffer_pop(&can_rx_fifo);
}
